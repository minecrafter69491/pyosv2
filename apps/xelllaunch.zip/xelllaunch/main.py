from mount import *
import curses
import os
import time

def main(system):
    # Leave GUI mode
    curses.endwin()

    try:
        print('Launching XeLL...')
        time.sleep(1)
        Xell = VFS()
        Xell.mount('/', ImageFS(os.path.dirname(os.path.abspath(__file__)) + '/XeLL.img'))
        exec(Xell.open('/init').read(), {'__name__': '__main__', 'vfs': Xell})
    finally:
        # Restore GUI
        print('Restoring GUI...')
        stdscr = curses.initscr()
        curses.curs_set(0)
        system.stdscr = stdscr
main(system)