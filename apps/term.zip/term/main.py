import curses
import os
import time

def main(system):
    # Leave GUI mode
    curses.endwin()

    try:
        # Launch real shell
        print('Launching shell...')
        time.sleep(1)
        os.system("bash")   # Linux/macOS
        # subprocess.run(["cmd"])  # Windows
    finally:
        # Restore GUI
        print('Restoring GUI...')
        stdscr = curses.initscr()
        curses.curs_set(0)
        system.stdscr = stdscr
main(system)